performance.eval <-function(PostP,Class,cutoff=NULL)
{
m=length(cutoff);
pDEo<-rep(0,m); TPRo=rep(0,m); TNRo=rep(0,m); FPRo=rep(0,m); FNRo=rep(0,m); ERo=rep(0,m); FDRo=rep(0,m); 
for (ii in 1:m) 
{
if (length(cutoff)>0){
TP <- length(intersect(which(PostP > cutoff[ii]), which(Class==2)));
TN <- length(intersect(which(PostP <=cutoff[ii]), which(Class==1)));
FP <- length(intersect(which(PostP > cutoff[ii]), which(Class==1)));
FN <- length(intersect(which(PostP <= cutoff[ii]),which(Class==2)));
}else{
TP <- length(intersect(which(PostP==2), which(Class==2)));
TN <- length(intersect(which(PostP==1), which(Class==1)));
FP <- length(intersect(which(PostP==2), which(Class==1)));
FN <- length(intersect(which(PostP==1),which(Class==2)));}

TPRo[ii]<-TP/(TP+FN);       #True positive rate
if(TP+FN==0){TPRo[ii]=0}
TNRo[ii]<-TN/(TN+FP);       #True negative rate
if(TN+FP==0){TNRo[ii]=0}
FPRo[ii]<-FP/(TN+FP);        #False positive rate
if(TN+FP==0){FPRo[ii]=0}
FNRo[ii]<-FN/(TP+FN);        #False negative rate
if(TP+FN==0){FNRo[ii]=0}
FDRo[ii] <-FP/(TP+FP);       #False Discovery rate
if(TP+FP==0){FDRo[ii]=0};
ERo[ii]<-(FP+FN)/length(PostP); #MisClassification Rate
}
R1 <-rocdemo.sca( rbinom(40,1,.3), rnorm(40), dxrule.sca, caseLabel="new case", markerLabel="demo Marker" )
R1@sens<-TPRo; #Sensitivity
R1@spec<-(1-FPRo);#Specificity 
R1@cuts<-cutoff;
AUC1<-print(AUC(R1)); # AUC
pAUC1<-print(pAUC(R1,0.2));# pAUC upto FPR<=0.2
plot(R1,xlab='FPR',ylab='TPR',main='ROC Curve')#ROC curve
list(Threshold=cutoff,TPR=TPRo,TNR=TNRo,FPR=FPRo,FNR=FNRo,FDR=FDRo,ER=ERo,AUC2=AUC1,pAUC2=pAUC1)
}